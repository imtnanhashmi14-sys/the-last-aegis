THE LAST AEGIS — ANDROID PROJECT
Producer: Imtnan Hashmi
Director: Imtnan Hashmi

IS ZIP MEIN KYA HAI
- Android Studio project scaffold
- Existing THE LAST AEGIS campaign HTML game bundled as app/src/main/assets/index.html
- Kotlin WebView launcher for landscape/full-screen mobile play
- Gradle Android build configuration

IMPORTANT
Yeh Android Studio project source hai, ready-made APK/AAB nahi. Is environment mein signed Android release build generate nahi hua.
Google Play ke liye:
1. Project ko Android Studio ke compatible, supported computer par open karein.
2. Android SDK Platform 36 aur JDK 17 install karein.
3. Gradle sync karein, phir app ko device/emulator par build aur test karein.
4. App signing set up karein aur Build > Generate Signed Bundle / APK > Android App Bundle select karein.
5. Release se pehle current Play Console requirements, privacy/data safety, content rating, screenshots aur app access details complete karein.

PROJECT DETAILS
Application ID: com.imtnanhashmi.thelastaegis
Version: 1.0.0
Minimum Android: API 23 (Android 6.0)
Target SDK: API 36
Orientation: Landscape

NOTE ABOUT GAME CONTENT
This package wraps the included browser game in a native Android WebView shell. It does not magically convert it into a native 3D engine game. The game logic and visuals are the included HTML game.
